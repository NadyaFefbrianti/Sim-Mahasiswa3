<?php
// prodi.php — READ: daftar program studi
require "auth.php";

$res = mysqli_query($conn, "SELECT p.id, p.kode, p.nama, COUNT(m.id) AS jumlah
                            FROM prodi p LEFT JOIN mahasiswa m ON m.prodi_id = p.id
                            GROUP BY p.id ORDER BY p.nama");
$prodi = mysqli_fetch_all($res, MYSQLI_ASSOC);

$judul = "Program studi"; $menu = "prodi";
include "_header.php";
?>
    <div class="page-head">
      <h1>Program studi</h1>
      <a class="btn btn-primary" href="prodi_tambah.php">Tambah program studi</a>
    </div>
    <section class="panel">
      <div class="table-scroll">
        <table>
          <thead><tr><th>No</th><th>Kode</th><th>Nama program studi</th><th>Jumlah mahasiswa</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php if (!$prodi): ?>
            <tr><td colspan="5" class="empty">Belum ada program studi. Klik “Tambah program studi”.</td></tr>
          <?php endif; ?>
          <?php $no = 0; foreach ($prodi as $p): $no++; ?>
            <tr>
              <td><?= $no ?></td>
              <td><?= e($p["kode"]) ?></td>
              <td><?= e($p["nama"]) ?></td>
              <td><a href="mahasiswa.php?prodi=<?= $p["id"] ?>"><?= $p["jumlah"] ?> mahasiswa</a></td>
              <td class="actions">
                <a class="btn btn-sm btn-edit" href="prodi_edit.php?id=<?= $p["id"] ?>">Ubah</a>
                <form method="post" action="prodi_hapus.php" onsubmit="return confirm('Hapus program studi <?= e(addslashes($p["nama"])) ?>?')">
                  <input type="hidden" name="csrf" value="<?= e($_SESSION["csrf"]) ?>">
                  <input type="hidden" name="id" value="<?= $p["id"] ?>">
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
<?php include "_footer.php"; ?>
