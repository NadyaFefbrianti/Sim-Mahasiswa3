<?php
// mahasiswa_edit.php — UPDATE
require "auth.php";

$id = (int)($_GET["id"] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT nim, nama, prodi_id, angkatan, email FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$data) {
    flash("Data mahasiswa tidak ditemukan.", "err");
    header("Location: mahasiswa.php");
    exit;
}

$daftar_prodi = mysqli_fetch_all(mysqli_query($conn, "SELECT id, nama FROM prodi ORDER BY nama"), MYSQLI_ASSOC);
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    cek_csrf();
    $data = [
        "nim" => trim($_POST["nim"] ?? ""),
        "nama" => trim($_POST["nama"] ?? ""),
        "prodi_id" => (int)($_POST["prodi_id"] ?? 0),
        "angkatan" => (int)($_POST["angkatan"] ?? 0),
        "email" => trim($_POST["email"] ?? ""),
    ];
    if ($data["nim"] === "" || $data["nama"] === "" || !$data["prodi_id"] || !$data["angkatan"]) {
        $error = "NIM, nama, program studi, dan angkatan wajib diisi.";
    } elseif ($data["email"] !== "" && !filter_var($data["email"], FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE mahasiswa SET nim=?, nama=?, prodi_id=?, angkatan=?, email=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssiisi", $data["nim"], $data["nama"], $data["prodi_id"], $data["angkatan"], $data["email"], $id);
        if (mysqli_stmt_execute($stmt)) {
            flash("Data " . $data["nama"] . " berhasil diperbarui.");
            header("Location: mahasiswa.php");
            exit;
        }
        $error = mysqli_stmt_errno($stmt) == 1062 ? "NIM " . $data["nim"] . " sudah dipakai mahasiswa lain." : "Data gagal diperbarui. Coba lagi.";
    }
}

$judul = "Ubah mahasiswa"; $menu = "mahasiswa"; $tombol = "Simpan perubahan";
include "_header.php";
?>
    <div class="page-head"><h1>Ubah data mahasiswa</h1></div>
    <section class="panel">
      <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
      <?php include "_form_mahasiswa.php"; ?>
    </section>
<?php include "_footer.php"; ?>
