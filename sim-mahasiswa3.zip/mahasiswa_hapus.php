<?php
// mahasiswa_hapus.php — DELETE (hanya lewat POST)
require "auth.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: mahasiswa.php");
    exit;
}
cek_csrf();

$id = (int)($_POST["id"] ?? 0);
$stmt = mysqli_prepare($conn, "DELETE FROM mahasiswa WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

if (mysqli_stmt_affected_rows($stmt) > 0) {
    flash("Data mahasiswa dihapus.");
} else {
    flash("Data tidak ditemukan atau sudah dihapus.", "err");
}
header("Location: mahasiswa.php");
exit;
