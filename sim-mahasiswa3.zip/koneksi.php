<?php
// koneksi.php — koneksi database MySQL (InfinityFree)
// Ganti 4 nilai di bawah sesuai panel InfinityFree: MySQL Databases

//   $db_host = "localhost";
//   $db_user = "root";
//   $db_pass = "";
//   $db_name = "simmhs3";
    
  $db_host = "sql209.infinityfree.com";   // MySQL Hostname
  $db_user = "if0_43401603";              // MySQL Username
  $db_pass = "0WpjrQ3ogg";     // Password akun hosting (vPanel)
  $db_name = "if0_43401603_simmhs3";       // Nama database

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8mb4");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
