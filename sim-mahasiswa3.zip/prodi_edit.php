<?php
// prodi_edit.php — UPDATE
require "auth.php";

$id = (int)($_GET["id"] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT kode, nama FROM prodi WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$data) {
    flash("Program studi tidak ditemukan.", "err");
    header("Location: prodi.php");
    exit;
}
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    cek_csrf();
    $data = ["kode" => strtoupper(trim($_POST["kode"] ?? "")), "nama" => trim($_POST["nama"] ?? "")];
    if ($data["kode"] === "" || $data["nama"] === "") {
        $error = "Kode dan nama program studi wajib diisi.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE prodi SET kode=?, nama=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssi", $data["kode"], $data["nama"], $id);
        if (mysqli_stmt_execute($stmt)) {
            flash("Program studi " . $data["nama"] . " berhasil diperbarui.");
            header("Location: prodi.php");
            exit;
        }
        $error = mysqli_stmt_errno($stmt) == 1062 ? "Kode " . $data["kode"] . " sudah dipakai prodi lain." : "Data gagal diperbarui. Coba lagi.";
    }
}

$judul = "Ubah program studi"; $menu = "prodi"; $tombol = "Simpan perubahan";
include "_header.php";
?>
    <div class="page-head"><h1>Ubah program studi</h1></div>
    <section class="panel">
      <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
      <?php include "_form_prodi.php"; ?>
    </section>
<?php include "_footer.php"; ?>
