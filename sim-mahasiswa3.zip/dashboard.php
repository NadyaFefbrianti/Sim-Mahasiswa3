<?php
// dashboard.php — ringkasan data (CRUD ada di mahasiswa.php dan prodi.php)
require "auth.php";

$prodi = mysqli_fetch_all(mysqli_query($conn,
    "SELECT p.id, p.nama, COUNT(m.id) AS jumlah
     FROM prodi p LEFT JOIN mahasiswa m ON m.prodi_id = p.id
     GROUP BY p.id ORDER BY p.nama"), MYSQLI_ASSOC);
$total = array_sum(array_column($prodi, "jumlah"));

$terbaru = mysqli_fetch_all(mysqli_query($conn,
    "SELECT m.nim, m.nama, m.angkatan, p.nama AS prodi
     FROM mahasiswa m JOIN prodi p ON p.id = m.prodi_id
     ORDER BY m.id DESC LIMIT 5"), MYSQLI_ASSOC);

$judul = "Dashboard"; $menu = "dashboard";
include "_header.php";
?>
    <div class="page-head">
      <h1>Dashboard</h1>
      <a class="btn btn-primary" href="mahasiswa_tambah.php">Tambah mahasiswa</a>
    </div>

    <section class="stats">
      <a class="stat" href="mahasiswa.php">
        <strong><?= $total ?></strong><span>Total mahasiswa</span>
      </a>
      <?php foreach ($prodi as $p): ?>
        <a class="stat" href="mahasiswa.php?prodi=<?= $p["id"] ?>">
          <strong><?= $p["jumlah"] ?></strong><span><?= e($p["nama"]) ?></span>
        </a>
      <?php endforeach; ?>
    </section>

    <section class="panel">
      <h2>Mahasiswa terbaru</h2>
      <div class="table-scroll">
        <table>
          <thead><tr><th>NIM</th><th>Nama</th><th>Program studi</th><th>Angkatan</th></tr></thead>
          <tbody>
          <?php if (!$terbaru): ?>
            <tr><td colspan="4" class="empty">Belum ada data mahasiswa.</td></tr>
          <?php endif; ?>
          <?php foreach ($terbaru as $m): ?>
            <tr><td><?= e($m["nim"]) ?></td><td><?= e($m["nama"]) ?></td><td><?= e($m["prodi"]) ?></td><td><?= e($m["angkatan"]) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p><a href="mahasiswa.php">Lihat semua mahasiswa</a></p>
    </section>
<?php include "_footer.php"; ?>
