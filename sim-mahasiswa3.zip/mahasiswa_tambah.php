<?php
// mahasiswa_tambah.php — CREATE
require "auth.php";

$daftar_prodi = mysqli_fetch_all(mysqli_query($conn, "SELECT id, nama FROM prodi ORDER BY nama"), MYSQLI_ASSOC);
$data = ["nim" => "", "nama" => "", "prodi_id" => 0, "angkatan" => date("Y"), "email" => ""];
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    cek_csrf();
    $data = [
        "nim" => trim($_POST["nim"] ?? ""),
        "nama" => trim($_POST["nama"] ?? ""),
        "prodi_id" => (int)($_POST["prodi_id"] ?? 0),
        "angkatan" => (int)($_POST["angkatan"] ?? 0),
        "email" => trim($_POST["email"] ?? ""),
    ];
    if ($data["nim"] === "" || $data["nama"] === "" || !$data["prodi_id"] || !$data["angkatan"]) {
        $error = "NIM, nama, program studi, dan angkatan wajib diisi.";
    } elseif ($data["email"] !== "" && !filter_var($data["email"], FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid.";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO mahasiswa (nim, nama, prodi_id, angkatan, email) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "ssiis", $data["nim"], $data["nama"], $data["prodi_id"], $data["angkatan"], $data["email"]);
        if (mysqli_stmt_execute($stmt)) {
            flash("Mahasiswa " . $data["nama"] . " berhasil ditambahkan.");
            header("Location: mahasiswa.php");
            exit;
        }
        $error = mysqli_stmt_errno($stmt) == 1062 ? "NIM " . $data["nim"] . " sudah terdaftar." : "Data gagal disimpan. Coba lagi.";
    }
}

$judul = "Tambah mahasiswa"; $menu = "mahasiswa"; $tombol = "Simpan mahasiswa";
include "_header.php";
?>
    <div class="page-head"><h1>Tambah mahasiswa</h1></div>
    <section class="panel">
      <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
      <?php include "_form_mahasiswa.php"; ?>
    </section>
<?php include "_footer.php"; ?>
