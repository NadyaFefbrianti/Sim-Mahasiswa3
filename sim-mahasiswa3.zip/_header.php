<?php
// _header.php — kepala halaman + menu. Set $judul dan $menu sebelum include.
$judul = $judul ?? "SIM Mahasiswa";
$menu  = $menu ?? "";
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($judul) ?> — SIM Mahasiswa</title>
  <link rel="stylesheet" href="style.css?v=3">
</head>
<body class="app">
  <header class="topbar">
    <a class="brand" href="dashboard.php">SIM Mahasiswa</a>
    <nav class="menu">
      <a href="dashboard.php" class="<?= $menu === "dashboard" ? "on" : "" ?>">Dashboard</a>
      <a href="mahasiswa.php" class="<?= $menu === "mahasiswa" ? "on" : "" ?>">Mahasiswa</a>
      <a href="prodi.php" class="<?= $menu === "prodi" ? "on" : "" ?>">Program studi</a>
    </nav>
    <div class="topbar-right">
      <span><?= e($_SESSION["user"]["nama"]) ?></span>
      <a class="btn btn-ghost" href="logout.php">Keluar</a>
    </div>
  </header>
  <main class="wrap">
<?php if (!empty($_SESSION["flash"])): [$fp, $ft] = $_SESSION["flash"]; unset($_SESSION["flash"]); ?>
    <div class="alert <?= $ft === "ok" ? "alert-ok" : "" ?>"><?= e($fp) ?></div>
<?php endif; ?>
