<?php
require "koneksi.php";

if (isset($_SESSION["user"])) {
    header("Location: dashboard.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = mysqli_prepare($conn, "SELECT id, password, nama_lengkap FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row && password_verify($password, $row["password"])) {
        session_regenerate_id(true);
        $_SESSION["user"] = ["id" => $row["id"], "nama" => $row["nama_lengkap"]];
        header("Location: dashboard.php");
        exit;
    }
    $error = "Username atau password salah. Periksa lagi lalu coba masuk.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Masuk — SIM Mahasiswa</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="auth">
  <main class="auth-box">
    <a class="brand" href="index.php">SIM Mahasiswa</a>
    <h1>Masuk ke sistem</h1>
    <p class="muted">Gunakan akun admin akademik.</p>

    <?php if ($error): ?>
      <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required autofocus>
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
      <button type="submit" class="btn btn-primary btn-block">Masuk</button>
    </form>
  </main>
</body>
</html>
