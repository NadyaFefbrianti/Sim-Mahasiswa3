<?php
// prodi_tambah.php — CREATE
require "auth.php";

$data = ["kode" => "", "nama" => ""];
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    cek_csrf();
    $data = ["kode" => strtoupper(trim($_POST["kode"] ?? "")), "nama" => trim($_POST["nama"] ?? "")];
    if ($data["kode"] === "" || $data["nama"] === "") {
        $error = "Kode dan nama program studi wajib diisi.";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO prodi (kode, nama) VALUES (?,?)");
        mysqli_stmt_bind_param($stmt, "ss", $data["kode"], $data["nama"]);
        if (mysqli_stmt_execute($stmt)) {
            flash("Program studi " . $data["nama"] . " berhasil ditambahkan.");
            header("Location: prodi.php");
            exit;
        }
        $error = mysqli_stmt_errno($stmt) == 1062 ? "Kode " . $data["kode"] . " sudah dipakai." : "Data gagal disimpan. Coba lagi.";
    }
}

$judul = "Tambah program studi"; $menu = "prodi"; $tombol = "Simpan program studi";
include "_header.php";
?>
    <div class="page-head"><h1>Tambah program studi</h1></div>
    <section class="panel">
      <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
      <?php include "_form_prodi.php"; ?>
    </section>
<?php include "_footer.php"; ?>
