<?php
// auth.php — dipanggil di awal setiap halaman yang butuh login
require_once "koneksi.php";

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}
if (empty($_SESSION["csrf"])) {
    $_SESSION["csrf"] = bin2hex(random_bytes(16));
}

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8");
}
function cek_csrf() {
    if (!hash_equals($_SESSION["csrf"], $_POST["csrf"] ?? "")) {
        die("Permintaan tidak valid.");
    }
}
function flash($pesan, $tipe = "ok") {
    $_SESSION["flash"] = [$pesan, $tipe];
}
