<?php
// prodi_hapus.php — DELETE (hanya lewat POST, ditolak kalau masih ada mahasiswa)
require "auth.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: prodi.php");
    exit;
}
cek_csrf();

$id = (int)($_POST["id"] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM mahasiswa WHERE prodi_id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$jumlah = (int)mysqli_fetch_row(mysqli_stmt_get_result($stmt))[0];

if ($jumlah > 0) {
    flash("Program studi tidak bisa dihapus karena masih punya $jumlah mahasiswa. Pindahkan atau hapus mahasiswanya dulu.", "err");
} else {
    $stmt = mysqli_prepare($conn, "DELETE FROM prodi WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    flash("Program studi dihapus.");
}
header("Location: prodi.php");
exit;
