<?php
// _form_prodi.php — formulir bersama untuk tambah & ubah prodi
// Butuh: $data (kode, nama), $tombol
?>
<form method="post" class="grid-form">
  <input type="hidden" name="csrf" value="<?= e($_SESSION["csrf"]) ?>">
  <div><label for="kode">Kode prodi</label><input id="kode" name="kode" maxlength="10" value="<?= e($data["kode"]) ?>" required></div>
  <div style="grid-column: span 2"><label for="nama">Nama program studi</label><input id="nama" name="nama" maxlength="100" value="<?= e($data["nama"]) ?>" required></div>
  <div class="end">
    <button class="btn btn-primary" type="submit"><?= e($tombol) ?></button>
    <a class="btn btn-ghost" href="prodi.php">Batal</a>
  </div>
</form>
