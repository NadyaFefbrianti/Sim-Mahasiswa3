<?php
// mahasiswa.php — READ: daftar mahasiswa + filter prodi + cari + halaman
require "auth.php";

$f_prodi = (int)($_GET["prodi"] ?? 0);
$q = trim($_GET["q"] ?? "");
$per_halaman = 10;
$hal = max(1, (int)($_GET["hal"] ?? 1));

$daftar_prodi = mysqli_fetch_all(mysqli_query($conn, "SELECT id, nama FROM prodi ORDER BY nama"), MYSQLI_ASSOC);

$where = " WHERE 1=1"; $types = ""; $params = [];
if ($f_prodi) { $where .= " AND m.prodi_id = ?"; $types .= "i"; $params[] = $f_prodi; }
if ($q !== "") { $where .= " AND (m.nama LIKE ? OR m.nim LIKE ?)"; $types .= "ss"; $params[] = "%$q%"; $params[] = "%$q%"; }

// total data
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM mahasiswa m" . $where);
if ($types) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$total = (int)mysqli_fetch_row(mysqli_stmt_get_result($stmt))[0];
$jml_hal = max(1, (int)ceil($total / $per_halaman));
$hal = min($hal, $jml_hal);
$offset = ($hal - 1) * $per_halaman;

// data halaman ini
$sql = "SELECT m.id, m.nim, m.nama, m.angkatan, m.email, p.nama AS prodi
        FROM mahasiswa m JOIN prodi p ON p.id = m.prodi_id" . $where . " ORDER BY m.nim LIMIT $per_halaman OFFSET $offset";
$stmt = mysqli_prepare($conn, $sql);
if ($types) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$mhs = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

function url_hal($n) {
    $p = $_GET; $p["hal"] = $n;
    return "mahasiswa.php?" . http_build_query($p);
}

$judul = "Data mahasiswa"; $menu = "mahasiswa";
include "_header.php";
?>
    <div class="page-head">
      <h1>Data mahasiswa</h1>
      <a class="btn btn-primary" href="mahasiswa_tambah.php">Tambah mahasiswa</a>
    </div>

    <section class="panel">
      <form method="get" class="search">
        <select name="prodi" aria-label="Filter program studi">
          <option value="0">Semua program studi</option>
          <?php foreach ($daftar_prodi as $p): ?>
            <option value="<?= $p["id"] ?>" <?= $f_prodi === (int)$p["id"] ? "selected" : "" ?>><?= e($p["nama"]) ?></option>
          <?php endforeach; ?>
        </select>
        <input type="search" name="q" placeholder="Cari nama atau NIM" value="<?= e($q) ?>">
        <button class="btn btn-primary" type="submit">Cari</button>
      </form>

      <div class="table-scroll">
        <table>
          <thead>
            <tr><th>No</th><th>NIM</th><th>Nama</th><th>Program studi</th><th>Angkatan</th><th>Email</th><th>Aksi</th></tr>
          </thead>
          <tbody>
          <?php if (!$mhs): ?>
            <tr><td colspan="7" class="empty">Belum ada data yang cocok. Klik “Tambah mahasiswa” untuk mengisi data.</td></tr>
          <?php endif; ?>
          <?php $no = $offset; foreach ($mhs as $m): $no++; ?>
            <tr>
              <td><?= $no ?></td>
              <td><?= e($m["nim"]) ?></td>
              <td><?= e($m["nama"]) ?></td>
              <td><?= e($m["prodi"]) ?></td>
              <td><?= e($m["angkatan"]) ?></td>
              <td><?= e($m["email"]) ?></td>
              <td class="actions">
                <a class="btn btn-sm btn-edit" href="mahasiswa_edit.php?id=<?= $m["id"] ?>">Ubah</a>
                <form method="post" action="mahasiswa_hapus.php" onsubmit="return confirm('Hapus <?= e(addslashes($m["nama"])) ?>?')">
                  <input type="hidden" name="csrf" value="<?= e($_SESSION["csrf"]) ?>">
                  <input type="hidden" name="id" value="<?= $m["id"] ?>">
                  <button class="btn btn-sm btn-danger" type="submit">Hapus</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="pager">
        <span class="muted"><?= $total ?> data · halaman <?= $hal ?> dari <?= $jml_hal ?></span>
        <span>
          <?php if ($hal > 1): ?><a class="btn btn-sm btn-ghost" href="<?= e(url_hal($hal - 1)) ?>">Sebelumnya</a><?php endif; ?>
          <?php if ($hal < $jml_hal): ?><a class="btn btn-sm btn-ghost" href="<?= e(url_hal($hal + 1)) ?>">Berikutnya</a><?php endif; ?>
        </span>
      </div>
    </section>
<?php include "_footer.php"; ?>
