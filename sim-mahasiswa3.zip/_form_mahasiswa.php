<?php
// _form_mahasiswa.php — formulir bersama untuk tambah & ubah mahasiswa
// Butuh: $data (array nim, nama, prodi_id, angkatan, email), $daftar_prodi, $tombol
?>
<form method="post" class="grid-form">
  <input type="hidden" name="csrf" value="<?= e($_SESSION["csrf"]) ?>">
  <div><label for="nim">NIM</label><input id="nim" name="nim" maxlength="20" value="<?= e($data["nim"]) ?>" required></div>
  <div><label for="nama">Nama lengkap</label><input id="nama" name="nama" maxlength="100" value="<?= e($data["nama"]) ?>" required></div>
  <div>
    <label for="prodi_id">Program studi</label>
    <select id="prodi_id" name="prodi_id" required>
      <option value="">Pilih program studi</option>
      <?php foreach ($daftar_prodi as $p): ?>
        <option value="<?= $p["id"] ?>" <?= (int)$data["prodi_id"] === (int)$p["id"] ? "selected" : "" ?>><?= e($p["nama"]) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div><label for="angkatan">Angkatan</label><input id="angkatan" name="angkatan" type="number" min="2000" max="2100" value="<?= e($data["angkatan"]) ?>" required></div>
  <div><label for="email">Email</label><input id="email" name="email" type="email" maxlength="100" value="<?= e($data["email"]) ?>"></div>
  <div class="end">
    <button class="btn btn-primary" type="submit"><?= e($tombol) ?></button>
    <a class="btn btn-ghost" href="mahasiswa.php">Batal</a>
  </div>
</form>
